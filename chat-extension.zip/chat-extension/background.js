browser.browserAction.onClicked.addListener(() => {
    browser.sidebarAction.toggle();
});